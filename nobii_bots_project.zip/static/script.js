document.addEventListener("DOMContentLoaded", function() {
    const links = document.querySelectorAll('nav ul li a');
    links.forEach(link => {
        link.addEventListener('mouseover', function() {
            link.style.color = '#00BFFF'; // Change color on hover
        });
        link.addEventListener('mouseout', function() {
            link.style.color = '#00FF00'; // Reset color
        });
    });
});