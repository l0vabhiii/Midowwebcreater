from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/bots')
def bots():
    return render_template('bots.html')

@app.route('/software')
def software():
    return render_template('software.html')

@app.route('/gambling')
def gambling():
    return render_template('gambling.html')

@app.route('/automated-solutions')
def automated_solutions():
    return render_template('automated_solutions.html')

if __name__ == '__main__':
    app.run(debug=True)